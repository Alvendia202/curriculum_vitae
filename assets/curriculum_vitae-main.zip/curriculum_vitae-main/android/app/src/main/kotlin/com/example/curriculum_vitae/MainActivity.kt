package com.example.curriculum_vitae

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
